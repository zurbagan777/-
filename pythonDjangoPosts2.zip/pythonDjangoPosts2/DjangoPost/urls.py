"""
URL configuration for DjangoPost project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Примеры:
Представления функций
 1. Добавьте импорт: из my_app импортируйте представления
 2. Добавьте URL в urlpatterns: path(", views.home, name='home")
Представления на основе классов
 1. Добавьте импорт: из other_app.views импортируйте Home
 2. Добавьте URL в urlpatterns: path(", Home.as_view(), name='home")
Включая другой URLconf
 1. Импортируем функцию include(): из django.urls импортируем include, path
 2. Добавляем URL в urlpatterns: path('блог/', include('блог.urls'))
"""
from django.contrib import admin
from django.urls import path, include


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('Posts.urls')),
    path('users/', include('users.urls')),

]
