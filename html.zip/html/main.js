// for (let i = 0; i < document.body.childNodes.length; i++) {
//     alert(document.body.childNodes[i])
// }
let div = document.createElement('div')
div.className = 'alert'
div.innerHTML = '<strong>всем привет</strong><br>ВЫ ПРОЧИТАЛИ ЭТО СООБЩЕНИЕ НА ЭКРАНЕ.<br>нажмите кнопку ок'
document.body.append(div)

ul3.before('before')
ul3.style.backgroundColor = 'green'
let liFirst = document.createElement('li')
liFirst.innerHTML='prepend111'
ul3.prepend(liFirst)
let liLast = document.createElement('li')
liLast.innerHTML='Last111'
ul3.append(liLast)

let name = prompt ('ВВЕДИТЕ ВАШЕ ИМЯ')
alert('привет, ' + name)