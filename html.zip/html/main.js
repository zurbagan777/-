// урок_1

// for (let i = 0; i < document.body.childNodes.length; i++) {
//     alert(document.body.childNodes[i])
// }
// let div = document.createElement('div')
// div.className = 'alert'
// div.innerHTML = '<strong>всем привет</strong><br>ВЫ ПРОЧИТАЛИ ЭТО СООБЩЕНИЕ НА ЭКРАНЕ.<br>нажмите кнопку ок'
// document.body.append(div)

// ul3.before('before')
// ul3.style.backgroundColor = 'green'
// let liFirst = document.createElement('li')
// liFirst.innerHTML='prepend111'
// ul3.prepend(liFirst)
// let liLast = document.createElement('li')
// liLast.innerHTML='Last111'
// ul3.append(liLast)
// let name = prompt ('ВВЕДИТЕ ВАШЕ ИМЯ')
// alert('привет, ' + name)

// урок_2

// 1
// let value1 = +prompt ('ВВЕДИТЕ ЧИСЛО: ')
// value = value**2
// alert('Число в степени = ' + value)

// 2
// let value1 = +prompt ('ВВЕДИТЕ первое ЧИСЛО: ')
// let value2 = +prompt ('ВВЕДИТЕ второе ЧИСЛО: ')
// value3 = (value1 + value2)/2
// alert ('среднее ' + value3)

//3
// value4 = +prompt('ВВЕДИТЕ ЧИСЛО:')
// value5 = value4*2
// alert('площадь = ' + value5)

//4
// const constKM = 0.621371
// value = +prompt('введите число: ')
// alert('милли = ' + value * constKM)

//5
// let value1 = +prompt('ВВЕДИТЕ первое ЧИСЛО: ')
// let value2 = +prompt('ВВЕДИТЕ второе ЧИСЛО: ')
// let a = value1 + value2
// let b = value1 - value2
// let c = value1 * value2
// let d = value1 / value2
// alert('операция \n' + a + '\n' + b + '\n' + c + '\n' + d + '\n')

//6
// let a = +prompt('ВВЕДИТЕ первое ЧИСЛО: ')
// let b = +prompt('ВВЕДИТЕ второе ЧИСЛО: ')
// alert('x = ' + ( x = -b/a ))

//7
// let hours = +prompt('ВВЕДИТЕ часы : ')
// let min = +prompt('ВВЕДИТЕ минуты : ')
// let hours2 = 24 - hours
// let min2 = 60 - min
// alert(`до следующего дня осталось ${hours2} час(а) и  ${ min2} минуты`)

//Работа с объектами
//создаем пустые объекты
// var obj = new Object()
// var obj2 = {}
// //добавляем свойство/атрибут и объект, обычный синтаксис массивов
// obj['Name'] = 'Vasya'
// obj.Age = 12
// alert(obj.Name + obj.Age )
// delete obj.Age
// alert(obj.Name + obj.Age )

// if ('Age' in obj){
//     alert('EXIST')
// }
// else{
//     alert('NOT EXIST')
// }

// var student = {
//     name: 'daria',
//     lastname: 'Petrova',
//     age: 23
// }
// var student2 = {
//     name: 'vova',
//     lastname: 'Petrov',
//     age: 23,
//     adress: {
//         street: 'Lenina',
//         city: 'moscow',
//         country: 'Russia'
//     }
// }
// // alert(student2.adress.city)

// for (var tempProperty in student) {
//     alert(tempProperty) //название свойства
//     alert(student[tempProperty]) //значение

// }

//массивы
// arrayName = new Array()
// arrayName = new Array(20)
// arrayName = new Array(1, 5, 44)
// var arr = []
// arr[0] = 34
// arr[1] = 1
// alert(arr.length)
// for (var i = 0; i < arr.length; i++) {
//     alert(arr[i])
// }

//двумерные массивы
// var arr = [
//     [1, 2, 3],
//     [2, 3, 6]
// ]


//lesson 12.08.24
// const today = new Date()
// console.log(today)
// console.log(Date.now())
// const today2 = new Date('2024-08-12')
// console.log(today2)
// const today3 = new Date(2024, 8, 12, 3, 45, 12, 500)
// //год, месяц 0-11, день, часы, минуты, сек, миллисек
// console.log(today3)
// const today4 = new Date(-172347108452)
// console.log(today4)
// let yeateday = new Date(today - 24 * 60 * 60 * 1000)
// let tomorrow = new Date(today + 24 * 60 * 60 * 1000)
// console.log(yeateday, today, tomorrow)
//функции Date
// getFullYear() //возвращает год из 4 цифр
// getMonth() //номер месяца
// getDate() //день
// getHours(), getMinutes() //...
// setFullYear()//устанавливаем год
// setMonth()//устанавливаем месяц
// getUTCFullYear()//год по гринвическому меридиану(+0)
// toLocaleString()//получение строки даты и времени в локальном формате
// toLocaleDateString()//строка даты в формате 21.09.21
// toLocaleTimeString()//строка времени 10:39:47

//пример Поиск даты которая приходится на тот же день недели в другом месяце
// let d = new Date('02/07/2022')
// let month = d.getMonth(), weekDay = d.getDay()
// console.log(weekDay, d.toLocaleDateString())
// for (let index = 0; index < 12; index++) {
//   if(index == month) continue
//   d.setMonth(index)
//     if(weekDay == d.getDay())
//        console.log(d, d.toLocaleDateString())
//     }
// function displayTime()
// {//ищем элемент с id=clock
//     let element = document.getElementById('clock')
//     //создаем переменную текущего времени
//     let now = new Date()
//     //отображаем время на странице  element
//     element.innerHTML = now.toLocaleTimeString()
//     //вызываем ф-ию каждую сек
//     setTimeout(displayTime, 1000)
// }
// //начинаем отсчет после загрузки документа
// window.onload = displayTime

// function onclickk(){
//     alert('Привет, так js то же работает')
// }

// practice 14.08.2024
// var isAdmin = confirm('вы администратор?')
// alert(isAdmin)

// Задания, в которых необходимо использовать WHILE

// var value = +prompt('сколько раз необходимо вывести решетку #?')
// while(value>0){
//     document.write('#')
//     value = value-1
// }

// 2.Пользователь ввел число, а на экран вывелись все числа 
// от введенного до 0.
// var value2 = +prompt('введите число: ')
// while(value2 >= 0){
//     document.write(`${value2} `)
//     value2 -= 1 
// }

// 3. Запросить число и степень. Возвести число в указанную 
// степень и вывести результат.
// var value3 = +prompt('введите число: ')
// var value4 = +prompt('введите степень числа: ')
// var value5 = 1
// while(value4 > 0){
         
//          value5 *= value3 
//          value4 =  value4-1
//      }
// document.write(value5)

// 4. Запросить 2 числа и найти все общие делители
// var num1 = +prompt('введите первое число: ')
// var num2 = +prompt('введите второе число : ')
// let commonDivisors = []
// let divisor = 1
// while (divisor <= Math.min(num1, num2)) {
//     if (num1 % divisor === 0 && num2 % divisor === 0) {
//       commonDivisors.push(divisor);
//     }
//     divisor++;
//   }
//   document.write(commonDivisors)

// 5. Посчитать факториал введенного пользователем числа
// var n = +prompt('введите  число: ')
// if (n < 0) {
//     document.write("Факториал не определен для отрицательных чисел")
//   } else if (n === 0) {
//     document.write("Факториал равен 1")
//   } else {
//     let factorial = 1
//     let i = 1
//     while (i <= n) {
//       factorial *= i
//       i++;
//     }
//     document.write(`факториал числа ${n} равен ${factorial}`)
// }

// Задания, в которых необходимо использовать DO WHILE
