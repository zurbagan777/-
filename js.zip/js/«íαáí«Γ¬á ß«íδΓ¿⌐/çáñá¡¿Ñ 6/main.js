const buttons = document.querySelectorAll(".button");

    buttons.forEach(button => {
      button.addEventListener("mouseover", () => {
        const tooltip = button.querySelector(".tooltip");
        const buttonRect = button.getBoundingClientRect();
        const tooltipRect = tooltip.getBoundingClientRect();

        // Проверка, помещается ли подсказка сверху
        if (buttonRect.top - tooltipRect.height < 0) {
          tooltip.classList.remove("top");
          tooltip.classList.add("bottom");
        }
      });
    });