const field = document.getElementById("field");
const ball = document.getElementById("ball");

field.addEventListener("click", (event) => {
  const clickX = event.clientX;
  const clickY = event.clientY;

  // const ballRadius = ball.offsetWidth / 2;

  // Проверка выхода за границы поля
  let newX = clickX 
  let newY = clickY 

  if (newX < 0) {
    newX = 0;
  } 

  if (newY < 0) {
    newY = 0;
  }

  ball.style.left = newX + "px";
  ball.style.top = newY + "px";
});