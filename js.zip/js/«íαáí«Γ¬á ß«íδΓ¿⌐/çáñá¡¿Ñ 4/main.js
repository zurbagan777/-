const redLight = document.getElementById("redLight");
const yellowLight = document.getElementById("yellowLight");
const greenLight = document.getElementById("greenLight");
const switchButton = document.getElementById("switchButton");

let currentLight = "red";

function switchLight() {
  if (currentLight === "red") {
    redLight.classList.remove("red");
    yellowLight.classList.add("yellow");
    currentLight = "yellow";
  } else if (currentLight === "yellow") {
    yellowLight.classList.remove("yellow");
    greenLight.classList.add("green");
    currentLight = "green";
  } else if (currentLight === "green") {
    greenLight.classList.remove("green");
    redLight.classList.add("red");
    currentLight = "red";
  }
}

switchButton.addEventListener("click", switchLight);