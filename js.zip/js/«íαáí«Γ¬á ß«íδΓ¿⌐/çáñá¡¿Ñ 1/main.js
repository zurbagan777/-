// Задание 1
// Создать html-страницу для ввода имени пользователя. 
// Необходимо проверять каждый символ, который вводит пользователь. Если он ввел цифру, то не отображать ее в input.
const nameInput = document.getElementById('nameInput');

nameInput.addEventListener('input', (event) => {
  const inputValue = event.target.value
  const filteredValue = inputValue.replace(/[0-9]/g, '') // Удаляем цифры
  event.target.value = filteredValue;
})