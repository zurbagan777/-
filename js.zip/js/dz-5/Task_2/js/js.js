document.querySelector("#mouse-coordinates").addEventListener("mousemove", function(event) {
  const { clientX, clientY } = event;
  this.textContent = "Координаты: " + clientX + ", " + clientY;
});

document.querySelector("#mouse-coordinates").addEventListener('click', function(event) {

  if (event.button === 0) {
    this.textContent += ' (Левая кнопка)'
  } 
});
// Этот код предотвращает появление контекстного меню при нажатии правой кнопки мыши
document.querySelector("#mouse-coordinates").addEventListener("contextmenu", function(event) {
   event.preventDefault();
  this.textContent += ' (Правая кнопка)'
 
 
});
