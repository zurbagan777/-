

const target = document.querySelector('.targ')

document.querySelector('.html').addEventListener('click', () => {
    if (target.tagName = "html")
        target.innerHTML =  "HTML (от англ. HyperText Markup Language — «язык гипертекстовой разметки»)" +
            " — стандартизированный язык гипертекстовой разметки документов для просмотра веб-страниц в браузере"


}
)
document.querySelector('.css').addEventListener('click', () => {


    if (target.className = "css") {
        target.innerHTML = 'CSS (Cascading Style Sheets) — язык таблиц стилей, который позволяет прикреплять' +
            'стиль (например, шрифты и цвет) к структурированным документам (например, документам HTML и приложениям XML)'
    }
})

document.querySelector('.js').addEventListener('click', () => {


    if (target.className = "js") {
        target.innerHTML = 'JavaScript (аббр. JS) — мультипарадигменный язык программирования. Поддерживает объектно-ориентированный,' +
            'императивный и функциональный стили. Является реализацией спецификации ECMAScript (стандарт ECMA-262)'
    }
})