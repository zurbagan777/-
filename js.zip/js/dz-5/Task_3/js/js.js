document.querySelector('input').addEventListener('click', function(){
    let q=value++
    document.querySelector('input').innerHTML=q
})


