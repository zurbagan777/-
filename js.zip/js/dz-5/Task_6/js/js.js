progBar=document.querySelector('.progress')
document.querySelector('.main').addEventListener('click', (e) => {
    if (e.target.tagName == "BUTTON"){
       console.log( progBar.value)
        progBar.value+=5
        
    }
})