window.generate.addEventListener("click", ()=> {
    
    var max = 100
    var rand = Math.ceil(Math.random() * max)
    
//    window.result.innerHTML = rand;
   document.querySelector('div').innerHTML=rand
          
})