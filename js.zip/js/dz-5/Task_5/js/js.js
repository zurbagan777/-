
document.querySelector('.main').addEventListener('click', (e) => {
    if (e.target.tagName == "BUTTON"){
       
        e.target.parentElement.remove();
    }
})