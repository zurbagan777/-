Получить информацию по проекту можно по ссылке: https://docs.google.com/document/d/1FsQQtVGoAhpuU3zreA_4b13APEuJCVgDuSVI033eX6g/edit?usp=sharing
